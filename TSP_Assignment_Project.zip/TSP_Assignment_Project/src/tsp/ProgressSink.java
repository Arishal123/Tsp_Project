package tsp;

/** Tiny callback so algorithms can stream (NFC, bestDistance) in real time. */
@FunctionalInterface
public interface ProgressSink {
    void record(long nfc, double bestDistance);
}