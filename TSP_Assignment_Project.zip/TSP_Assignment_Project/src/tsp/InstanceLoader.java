package tsp;

import java.io.*;
import java.util.*;

public class InstanceLoader {
    /**
     * Load a TSPLIB-style instance:
     * Skips headers like NAME:, COMMENT:, DIMENSION:, NODE_COORD_SECTION, EOF
     * Reads lines of the form: id x y
     */
    public static City[] load(String path) {
        List<City> cities = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            boolean coordsSection = false;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                // Skip TSPLIB headers
                if (line.startsWith("NAME:") || line.startsWith("TYPE:") ||
                        line.startsWith("COMMENT:") || line.startsWith("DIMENSION:") ||
                        line.startsWith("EDGE_WEIGHT_TYPE:") || line.startsWith("EOF")) {
                    continue;
                }
                if (line.startsWith("NODE_COORD_SECTION")) {
                    coordsSection = true;
                    continue;
                }

                // Parse coordinates once we're in NODE_COORD_SECTION or if plain file
                String[] parts = line.split("\\s+|,");
                if (parts.length < 3) continue;

                try {
                    int id = Integer.parseInt(parts[0]);
                    double x = Double.parseDouble(parts[1]);
                    double y = Double.parseDouble(parts[2]);
                    cities.add(new City(id, x, y));
                } catch (NumberFormatException e) {
                    // Ignore any malformed line
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Failed to read instance: " + path, e);
        }
        return cities.toArray(new City[0]);
    }
}
