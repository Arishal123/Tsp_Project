package tsp;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

public class Plotter extends JPanel {
    private final List<Double> xGA, yGA;
    private final List<Double> xDP, yDP;
    private final String title;
    private final String xLabel;
    private final String yLabel;

    public Plotter(String title, String xLabel, String yLabel,
                   List<Double> xGA, List<Double> yGA,
                   List<Double> xDP, List<Double> yDP) {
        this.title = title;
        this.xLabel = xLabel;
        this.yLabel = yLabel;
        this.xGA = xGA; this.yGA = yGA;
        this.xDP = xDP; this.yDP = yDP;
        setPreferredSize(new Dimension(800, 500));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth(), h = getHeight();
        int left = 70, right = 20, top = 40, bottom = 60;
        // title
        g2.setFont(g2.getFont().deriveFont(Font.BOLD, 16f));
        FontMetrics fm = g2.getFontMetrics();
        int tw = fm.stringWidth(title);
        g2.drawString(title, (w - tw) / 2, top - 10);

        // axis
        int x0 = left, y0 = h - bottom;
        int x1 = w - right, y1 = top;
        g2.drawRect(x0, y1, x1 - x0, y0 - y1);

        // labels
        g2.setFont(g2.getFont().deriveFont(12f));
        g2.drawString(xLabel, (w - g2.getFontMetrics().stringWidth(xLabel)) / 2, h - 20);
        // rotate for y label
        g2.rotate(-Math.PI/2);
        g2.drawString(yLabel, -(h + g2.getFontMetrics().stringWidth(yLabel)) / 2, 20);
        g2.rotate(Math.PI/2);

        // find ranges
        double xmin = Double.POSITIVE_INFINITY, xmax = Double.NEGATIVE_INFINITY;
        double ymin = Double.POSITIVE_INFINITY, ymax = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < xGA.size(); i++) { xmin = Math.min(xmin, xGA.get(i)); xmax = Math.max(xmax, xGA.get(i)); }
        for (int i = 0; i < xDP.size(); i++) { xmin = Math.min(xmin, xDP.get(i)); xmax = Math.max(xmax, xDP.get(i)); }
        for (int i = 0; i < yGA.size(); i++) { ymin = Math.min(ymin, yGA.get(i)); ymax = Math.max(ymax, yGA.get(i)); }
        for (int i = 0; i < yDP.size(); i++) { ymin = Math.min(ymin, yDP.get(i)); ymax = Math.max(ymax, yDP.get(i)); }
        if (!Double.isFinite(xmin) || xmin == xmax) { xmin = 0; xmax = 1; }
        if (!Double.isFinite(ymin) || ymin == ymax) { ymin = 0; ymax = 1; }

        // padding
        double xpad = (xmax - xmin) * 0.05;
        double ypad = (ymax - ymin) * 0.05;
        xmin -= xpad; xmax += xpad;
        ymin -= ypad; ymax += ypad;

        // draw lines
        drawSeries(g2, xGA, yGA, x0, y0, x1, y1, xmin, xmax, ymin, ymax, Color.BLUE, "GA");
        drawSeries(g2, xDP, yDP, x0, y0, x1, y1, xmin, xmax, ymin, ymax, Color.RED, "DP");

        // legend
        int lx = x1 - 150, ly = y1 + 20;
        g2.setColor(Color.BLUE); g2.drawLine(lx, ly, lx+20, ly); g2.setColor(Color.BLACK); g2.drawString("GA", lx+30, ly+5);
        g2.setColor(Color.RED); g2.drawLine(lx, ly+20, lx+20, ly+20); g2.setColor(Color.BLACK); g2.drawString("DP", lx+30, ly+25);
    }

    private void drawSeries(Graphics2D g2, List<Double> xs, List<Double> ys,
                            int x0, int y0, int x1, int y1,
                            double xmin, double xmax, double ymin, double ymax,
                            Color color, String label) {
        if (xs.isEmpty()) return;
        g2.setColor(color);
        int prevX = -1, prevY = -1;
        for (int i = 0; i < xs.size(); i++) {
            int px = (int) (x0 + (xs.get(i) - xmin) * (x1 - x0) / (xmax - xmin));
            int py = (int) (y0 - (ys.get(i) - ymin) * (y0 - y1) / (ymax - ymin));
            if (prevX != -1) g2.drawLine(prevX, prevY, px, py);
            prevX = px; prevY = py;
        }
    }

    public static void showAndSave(String title, String xLabel, String yLabel,
                                   List<Double> xGA, List<Double> yGA,
                                   List<Double> xDP, List<Double> yDP,
                                   String outPng) throws IOException {
        Plotter panel = new Plotter(title, xLabel, yLabel, xGA, yGA, xDP, yDP);
        JFrame f = new JFrame(title);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.getContentPane().add(panel);
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);

        // Save PNG
        BufferedImage img = new BufferedImage(panel.getWidth(), panel.getHeight(), BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        panel.paint(g2);
        g2.dispose();
        ImageIO.write(img, "png", new File(outPng));
    }
}