package tsp;

import java.io.*;
import java.util.*;

public class ResultsWriter {
    public static void appendCSV(String path, String headerIfNew, List<String> rows) {
        boolean newFile = !(new File(path).exists());
        try (PrintWriter pw = new PrintWriter(new FileWriter(path, true))) {
            if (newFile && headerIfNew != null) pw.println(headerIfNew);
            for (String r : rows) pw.println(r);
        } catch (IOException e) {
            throw new RuntimeException("Failed to write results CSV", e);
        }
    }
}