package tsp;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;

public class RealTimeChart extends JFrame {

    private final XYSeries seriesGA;
    private final XYSeries seriesDP;

    public RealTimeChart(String instanceLabel) {
        super("GA vs DP — " + instanceLabel);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 600);

        seriesGA = new XYSeries("Genetic Algorithm");
        seriesDP = new XYSeries("Dynamic Programming");

        XYSeriesCollection ds = new XYSeriesCollection();
        ds.addSeries(seriesGA);
        ds.addSeries(seriesDP);

        JFreeChart chart = ChartFactory.createXYLineChart(
                "GA vs DP Progress — " + instanceLabel,
                "NFC / Generation",
                "Tour Length (Fitness)",
                ds
        );
        ChartPanel panel = new ChartPanel(chart);
        panel.setPreferredSize(new Dimension(900, 600));
        setContentPane(panel);
    }

    public void updateGA(int x, double y) {
        SwingUtilities.invokeLater(() -> seriesGA.add(x, y));
    }

    public void updateDP(int x, double y) {
        SwingUtilities.invokeLater(() -> seriesDP.add(x, y));
    }
}
