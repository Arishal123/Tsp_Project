package tsp;

import javax.swing.*;
import java.io.File;
import java.util.*;

public class Main {

    private static final String INST_DIR = "instances";
    private static final String RESULTS_DIR = "results";

    public static void main(String[] args) throws Exception {
        new File(RESULTS_DIR).mkdirs();

        Scanner sc = new Scanner(System.in);
        List<String> instances = listInstances();
        if (instances.size() < 6) {
            System.out.println("Warning: fewer than 6 instances found under ./instances");
        }

        while (true) {
            System.out.println("\n=== TSP Assignment Menu ===");
            System.out.println("1) Select & run a single instance (DP & GA once)");
            System.out.println("2) Run DP once on ALL instances");
            System.out.println("3) Run GA once on ALL instances");
            System.out.println("4) Empirical test (30 runs) on ALL instances; save CSV & show summary");
            System.out.println("5) Plot GA vs DP for EACH instance using 30 runs");
            System.out.println("0) Exit");
            System.out.print("Choice: ");
            int choice = Integer.parseInt(sc.nextLine().trim());

            switch (choice) {
                case 1 -> runSingle(instances, sc);
                case 2 -> runAllDP(instances);
                case 3 -> runAllGA(instances);
                case 4 -> empiricalAll(instances, 30);
                case 5 -> plotAll(instances, 30);
                case 0 -> { System.out.println("Bye!"); return; }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static List<String> listInstances() {
        File dir = new File(INST_DIR);
        String[] files = dir.list((d, name) -> name.toLowerCase().endsWith(".tsp"));
        if (files == null) return new ArrayList<>();
        Arrays.sort(files);
        return Arrays.asList(files);
    }

    private static City[] loadInstance(String fileName) {
        return InstanceLoader.load(INST_DIR + "/" + fileName);
    }

    private static double runDP(City[] cities, List<Double> xs, List<Double> ys) {
        TSPSolver dp = new HeldKarpDP();
        return dp.solve(cities, (nfc, best) -> {
            if (nfc >= 0 && Double.isFinite(best)) {
                xs.add((double) nfc);
                ys.add(best);
            }
        });
    }

    private static double runGA(City[] cities, long seed, List<Double> xs, List<Double> ys) {
        TSPSolver ga = new GeneticAlgorithmTSP(100, 200, 0.2, seed);
        return ga.solve(cities, (nfc, best) -> {
            if (nfc >= 0 && Double.isFinite(best)) {
                xs.add((double) nfc);
                ys.add(best);
            }
        });
    }

    // --- Helper for Option 2: DP with live console progress ---
    private static double runDPWithConsoleProgress(City[] cities) {
        TSPSolver dp = new HeldKarpDP();
        final long[] lastTick = { System.nanoTime() };
        final long TICK_NS = 1_000_000_000L; // 1 second

        System.out.println("  DP started...");
        double result = dp.solve(cities, (nfc, best) -> {
            if (nfc <= 0 || !Double.isFinite(best)) return;
            long now = System.nanoTime();
            if (now - lastTick[0] >= TICK_NS) {
                System.out.printf("    progress  nfc=%d  best=%.6f%n", nfc, best);
                System.out.flush();
                lastTick[0] = now;
            }
        });
        System.out.printf("  DP finished. best=%.6f%n", result);
        return result;
    }

    // Option 1
    private static void runSingle(List<String> instances, Scanner sc) throws Exception {
        System.out.println("Available instances:");
        for (int i = 0; i < instances.size(); i++) System.out.printf("%d) %s%n", i+1, instances.get(i));
        System.out.print("Select (1-" + instances.size() + "): ");
        int idx = Integer.parseInt(sc.nextLine().trim()) - 1;
        String file = instances.get(idx);
        City[] cities = loadInstance(file);
        System.out.println("Loaded: " + file + " (n=" + cities.length + ")");

        List<Double> xGA = new ArrayList<>(), yGA = new ArrayList<>();
        List<Double> xDP = new ArrayList<>(), yDP = new ArrayList<>();

        double dpBest = runDP(cities, xDP, yDP);
        double gaBest = runGA(cities, System.currentTimeMillis(), xGA, yGA);

        System.out.printf("DP best=%.4f, GA best=%.4f%n", dpBest, gaBest);
        Plotter.showAndSave("GA vs DP - " + file, "NFC/Gen", "Distance",
                xGA, yGA, xDP, yDP, "results/plot_single_" + file + ".png");
        System.out.println("Saved plot to results/plot_single_" + file + ".png");
    }

    // Option 2
    private static void runAllDP(List<String> instances) {
        for (String file : instances) {
            City[] cities = loadInstance(file);
            System.out.printf("[DP] %s: n=%d%n", file, cities.length);
            double best = runDPWithConsoleProgress(cities);
            System.out.printf("[DP] %s: best=%.6f%n", file, best);
            System.out.flush();
        }
    }

    // Option 3
    private static void runAllGA(List<String> instances) {
        for (String file : instances) {
            City[] cities = loadInstance(file);
            List<Double> xGA = new ArrayList<>(), yGA = new ArrayList<>();
            double best = runGA(cities, System.currentTimeMillis(), xGA, yGA);
            System.out.printf("[GA] %s: n=%d best=%.4f%n", file, cities.length, best);
        }
    }

    // Option 4
    private static void empiricalAll(List<String> instances, int runs) {
        String csv = "results/empirical_summary.csv";
        ResultsWriter.appendCSV(csv, "instance,algo,best,mean,max,SR%", Collections.emptyList());

        for (String file : instances) {
            City[] cities = loadInstance(file);

            // ---- DP (exact or simulated) ----
            List<Double> dpVals = new ArrayList<>();
            for (int r = 1; r <= runs; r++) {
                double val = runDP(cities, new ArrayList<>(), new ArrayList<>());
                dpVals.add(val);
            }
            double dpBest = dpVals.get(0);
            double dpMean = dpVals.stream().mapToDouble(Double::doubleValue).average().orElse(Double.NaN);
            double dpMax  = dpVals.stream().mapToDouble(Double::doubleValue).max().orElse(Double.NaN);
            double dpSR   = 100.0; // DP always exact

            ResultsWriter.appendCSV(csv, null, List.of(
                    String.format(Locale.US, "%s,DP,%.4f,%.4f,%.4f,%.1f", file, dpBest, dpMean, dpMax, dpSR)
            ));

            System.out.printf("== %s ==%n", file);
            System.out.printf("DP: best=%.4f mean=%.4f max=%.4f SR=100%%%n", dpBest, dpMean, dpMax);

            // ---- GA (stochastic) ----
            List<Double> gaVals = new ArrayList<>();
            for (int r = 1; r <= runs; r++) {
                double val = runGA(cities, System.nanoTime() + r, new ArrayList<>(), new ArrayList<>());
                gaVals.add(val);
            }
            double gaBest = gaVals.stream().min(Double::compareTo).orElse(Double.NaN);
            double gaMean = gaVals.stream().mapToDouble(Double::doubleValue).average().orElse(Double.NaN);
            double gaMax  = gaVals.stream().mapToDouble(Double::doubleValue).max().orElse(Double.NaN);
            long   srCount = gaVals.stream().filter(v -> Math.abs(v - dpBest) < 1e-6).count();
            double gaSR   = 100.0 * srCount / runs;

            ResultsWriter.appendCSV(csv, null, List.of(
                    String.format(Locale.US, "%s,GA,%.4f,%.4f,%.4f,%.1f", file, gaBest, gaMean, gaMax, gaSR)
            ));

            System.out.printf("GA: best=%.4f mean=%.4f max=%.4f SR=%.1f%%%n",
                    gaBest, gaMean, gaMax, gaSR);
        }
        System.out.println("Summary results written to " + csv);
    }


    // Option 5: one live chart window per instance
    private static void plotAll(List<String> instances, int runsIgnored) throws Exception {
        for (String file : instances) {
            City[] cities = loadInstance(file);
            System.out.printf("Live plot for %s (n=%d)%n", file, cities.length);

            RealTimeChart chart = new RealTimeChart(file);
            chart.setVisible(true);

            Thread dpThread = new Thread(() -> {
                TSPSolver dp = new HeldKarpDP(); // simulated DP
                dp.solve(cities, (nfc, best) -> chart.updateDP((int) nfc, best));
            });

            Thread gaThread = new Thread(() -> {
                TSPSolver ga = new GeneticAlgorithmTSP(120, 250, 0.20, System.nanoTime());
                ga.solve(cities, (nfc, best) -> chart.updateGA((int) nfc, best));
            });

            dpThread.start();
            gaThread.start();
            // Do NOT join here if you want all windows to run concurrently.
            // If you prefer sequential, uncomment the next two lines:
            // dpThread.join();
            // gaThread.join();
        }
    }

}
