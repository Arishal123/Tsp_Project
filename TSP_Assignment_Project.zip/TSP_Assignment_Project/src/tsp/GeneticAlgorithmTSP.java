package tsp;

import java.util.*;

public class GeneticAlgorithmTSP implements TSPSolver {

    private final int populationSize;
    private final int generations;
    private final double mutationRate;
    private final Random rng;

    public GeneticAlgorithmTSP(int populationSize, int generations, double mutationRate, long seed) {
        this.populationSize = populationSize;
        this.generations = generations;
        this.mutationRate = mutationRate;
        this.rng = new Random(seed);
    }

    @Override public String name() { return "Genetic Algorithm"; }

    @Override
    public double solve(City[] cities, ProgressSink sink) {
        int n = cities.length;

        // distance matrix
        double[][] d = new double[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                d[i][j] = cities[i].distanceTo(cities[j]);

        // init population (permutation of 0..n-1)
        List<int[]> pop = new ArrayList<>();
        int[] base = new int[n];
        for (int i = 0; i < n; i++) base[i] = i;
        for (int i = 0; i < populationSize; i++) {
            int[] perm = base.clone();
            shuffle(perm);
            pop.add(perm);
        }

        double best = Double.POSITIVE_INFINITY;
        for (int gen = 0; gen < generations; gen++) {
            // evaluate
            double[] fit = new double[populationSize];
            for (int i = 0; i < populationSize; i++) {
                fit[i] = tourLen(d, pop.get(i));
                if (fit[i] < best) best = fit[i];
            }

            // stream progress (X = gen/NFC, Y = best distance)
            if (sink != null) sink.record(gen, best);

            // selection + crossover + mutation (elitism)
            List<int[]> next = new ArrayList<>();
            int elite = argMin(fit);
            next.add(pop.get(elite).clone());
            while (next.size() < populationSize) {
                int a = tournament(fit, 3), b = tournament(fit, 3);
                int[] child = orderX(pop.get(a), pop.get(b));
                if (rng.nextDouble() < mutationRate) mutateSwap(child);
                next.add(child);
            }
            pop = next;
        }
        return best;
    }

    private void shuffle(int[] a) { for (int i = a.length-1; i>0; i--) { int j = rng.nextInt(i+1); int t=a[i]; a[i]=a[j]; a[j]=t; } }
    private int argMin(double[] x){ int m=0; for(int i=1;i<x.length;i++) if(x[i]<x[m]) m=i; return m; }
    private int tournament(double[] f,int k){ int idx=rng.nextInt(f.length); double best=f[idx];
        for(int i=1;i<k;i++){ int j=rng.nextInt(f.length); if(f[j]<best){best=f[j]; idx=j;}} return idx; }

    private double tourLen(double[][] d, int[] p) {
        double s = 0; for (int i=0;i<p.length;i++) s += d[p[i]][p[(i+1)%p.length]]; return s;
    }

    // Order Crossover (OX)
    private int[] orderX(int[] p1, int[] p2) {
        int n = p1.length; int[] c = new int[n]; Arrays.fill(c,-1);
        int a = rng.nextInt(n), b = rng.nextInt(n); if (a>b) {int t=a;a=b;b=t;}
        boolean[] used = new boolean[n+1000];
        for (int i=a;i<=b;i++){ c[i]=p1[i]; used[p1[i]] = true; }
        int idx=(b+1)%n;
        for (int i=0;i<n;i++){
            int g = p2[(b+1+i)%n];
            if (!used[g]) { c[idx]=g; used[g]=true; idx=(idx+1)%n; }
        }
        return c;
    }

    private void mutateSwap(int[] a) {
        if (a.length<2) return; int i=rng.nextInt(a.length), j=rng.nextInt(a.length);
        int t=a[i]; a[i]=a[j]; a[j]=t;
    }
}
