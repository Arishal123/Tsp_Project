package tsp;

public interface TSPSolver {
    /** Solve the TSP on given cities; return best tour length (exact if algorithm is exact). */
    double solve(City[] cities, ProgressSink sink);

    /** Name for charts/labels. */
    String name();
}