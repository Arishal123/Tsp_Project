# CS214 TSP Project – DP vs GA (6 Instances)

This project implements:
1. **Instance selection** (menu option 1)  
2. **Run DP once on all 6 instances** (option 2)  
3. **Run GA once on all 6 instances** (option 3)  
4. **Empirical testing**: run **30 times** on all instances, **store results** to `results/empirical.csv`, and **print summary** (option 4)  
5. **Plot graphs** of **GA vs DP** for each instance by running it **30 times** and saving PNGs to `results/` (option 5).

### Algorithms
- **DP (Held–Karp, layered)**: exact for small–medium `n`, streams progress (NFC vs best distance).
- **Genetic Algorithm**: order crossover + swap mutation, stochastic; streams progress (NFC vs best distance).

> Assignment requirements taken from the brief (empirical testing, 6 instances, real‑time progress, etc.). fileciteturn1file0L1-L36 fileciteturn1file0L37-L85

### Build & Run (no external libraries)
- Requires **Java 17+**.
```bash
# from project root
javac -d out src/tsp/*.java
java -cp out tsp.Main
```
Charts use **Java2D** + Swing; PNGs are saved into `results/`.

### Instances
Six small/medium Euclidean TSPLIB‑style files are under `instances/` (format: `id x y`).  
You can add your own files in the same format.

### Output
- **Console** prints best distances and empirical summaries (best/mean/max/SR).  
- **CSV**: `results/empirical.csv` with columns: `instance,algo,run,final_distance`.  
- **Plots**: PNGs saved in `results/`:
  - `plot_single_<instance>.png` for option 1
  - `plot_30runs_<instance>.png` for option 5

### Notes
- DP is **exact** but **exponential time**; the provided instances keep run times reasonable on a typical laptop.
- GA parameters (population=100, generations=200, mutation=0.2) can be tuned in `Main.runGA`.
- NFC in GA equals **evaluations** across generations; NFC in DP is an internal **state‑update counter**.

Good luck with your demo! 🎓